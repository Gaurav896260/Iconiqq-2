This demo font is for PERSONAL USE ONLY!

Link to purchase full version and commercial :
https://creativemarket.com/NestStd/5811715-Vilaka-Modern-Serif

If you need an extended license or corporate license, please contact me at amnestian@gmail.com

Please visit my store for more great fonts :
https://creativemarket.com/NestStd

And follow my instagram : @nestype.co